
from kafka import KafkaConsumer
import json
import numpy as np
from sklearn.ensemble import IsolationForest

consumer = KafkaConsumer(
"patient_vitals",
bootstrap_servers="localhost:9092",
value_deserializer=lambda m: json.loads(m.decode("utf-8"))
)

model = IsolationForest(contamination=0.1)
model.fit(np.random.rand(100,4))

for message in consumer:
    data = message.value

    vitals = np.array([[
        data["heart_rate"],
        data["spo2"],
        data["temperature"],
        data["blood_pressure"]
    ]])

    prediction = model.predict(vitals)

    severity = "HIGH" if prediction[0] == -1 else "LOW"

    print("Vitals:", data, "Severity:", severity)
