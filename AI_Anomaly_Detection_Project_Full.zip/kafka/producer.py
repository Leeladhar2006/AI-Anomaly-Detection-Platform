
from kafka import KafkaProducer
import json, time, random

producer = KafkaProducer(
bootstrap_servers='localhost:9092',
value_serializer=lambda v: json.dumps(v).encode('utf-8')
)

while True:
    data = {
        "heart_rate": random.randint(60,120),
        "spo2": random.randint(90,100),
        "temperature": round(random.uniform(36,39),2),
        "blood_pressure": random.randint(90,150)
    }

    producer.send("patient_vitals", data)
    print("Sent:", data)
    time.sleep(2)
