
from flask import Flask, jsonify

app = Flask(__name__)

@app.route("/")
def home():
    return "AI-Based Anomaly Detection Platform Running"

@app.route("/status")
def status():
    return jsonify({
        "system":"running",
        "model":"Isolation Forest",
        "monitoring":"patient vitals"
    })

if __name__ == "__main__":
    app.run(debug=True)
