
# AI-Based Anomaly Detection Platform

## Overview
This project is a real-time healthcare monitoring system that detects abnormal patterns in patient vital signs using machine learning.

## Technologies
Python, Apache Kafka, Flask, PostgreSQL, Machine Learning

## Features
- Real-time patient monitoring
- AI anomaly detection
- Severity classification (LOW, MEDIUM, HIGH)
- Flask API backend
- Simple dashboard
- Email alerts

## Workflow
Producer -> Kafka -> Consumer -> ML Model -> Severity Detection -> Dashboard / Alerts
